# fernandev

## React Interview Challenge #01

### Desafio proposto

https://liberating-keyboard-bc0.notion.site/React-Interview-Challenge-a1ad5bc0e374436f905bc4decb246fa8

### Resolução do desafio

https://youtu.be/qmZLWBOOfVQ

## Dê uma estrela no repo

Caso esse conteúdo tenha te ajudado de alguma maneira.
